<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use App\Models\BukuModel;

class Buku extends Seeder
{
    public function run()
    {
        $this->db->table('buku')->insert([
            'judul' => 'EXO',
            'penulis' => 'PDNIM',
            'penerbit' => 'PT SM',
            'tahun_terbit' => '2020'
        ]);

        $this->db->table('buku')->insert([
            'judul' => 'Seveteen',
            'penulis' => 'PDNIM',
            'penerbit' => 'PT Pledis',
            'tahun_terbit' => '2020'
        ]);

        $this->db->table('buku')->insert([
            'judul' => 'ITZY',
            'penulis' => 'PDNIM',
            'penerbit' => 'PT JYP',
            'tahun_terbit' => '2020'
        ]);
    }
}
